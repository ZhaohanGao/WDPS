# How To Run Our Project Group 31

## 1. System Requirements

Before getting started, make sure you have the following software installed on your system:

- Python 3.9.12 or higher
- pip (Python package manager)
- Docker

## 2. Pull and Run Docker Image

This project should be run in a specific docker image.

Pull the docker image:

```
docker pull karmaresearch/wdps2
```

Run the docker image:

```shel
docker run -ti karmaresearch/wdps2
```

upload the file to the docker image:

```shell
docker cp D:\WorkSpace\WDP\global_multi_demo.py 6f1cdb859689582383ca9c67f39226ac5d0720efe19e78202d0c526e186cdace:/home/user

docker cp D:\WorkSpace\WDP\requirements.txt 6f1cdb859689582383ca9c67f39226ac5d0720efe19e78202d0c526e186cdace:/home/user
```

If you already have a requirement.txt file in your folder, make sure you delete that first

## 3. Install Dependencies

Install all the dependencies listed in the `requirements.txt` file:

```
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

## 4. Configure LLM Model File

This project requires a `.gguf` LLM model file. Follow these steps to configure it:

### 4.1 Model File Location

Place your `llama-2-7b.Q4_K_M.gguf` model file in a specific directory within the project (e.g., `models/`).

### 4.2 Configure Model Path

In the global_multi_demo.py file, line 212, specify the path to the model file. For example, if your model file is in the ‘model’ folder, you can configure it like this:

```
llm_model = Llama("models/llama-2-7b.Q4_K_M.gguf", verbose=False)
```

## 5. Start the Project

Once the dependencies are installed and the model file is configured, you can start the project.

```
python global_multi_demo.py
```
